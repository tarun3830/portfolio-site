const badgeSelector =
  '#__framer-badge-container, .__framer-badge, a[href="https://www.framer.com/"][data-nosnippet="true"]';

const removeFramerBadges = (root = document) => {
  if (root instanceof Element && root.matches(badgeSelector)) {
    root.remove();
    return;
  }

  root.querySelectorAll?.(badgeSelector).forEach((badge) => badge.remove());
};

removeFramerBadges();

new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    mutation.addedNodes.forEach((node) => {
      if (node instanceof Element) removeFramerBadges(node);
    });
  }
}).observe(document.documentElement, { childList: true, subtree: true });
