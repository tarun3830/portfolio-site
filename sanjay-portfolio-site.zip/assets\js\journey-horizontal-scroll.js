const journeyHeading = document.querySelector('[data-framer-name="journey so far"]');
const journeySection = journeyHeading?.closest("section");
const journeySlots = journeySection?.querySelectorAll("[data-hzs-slot]");
const journeyTrack = journeySlots?.[0]?.parentElement;
const journeyViewport = journeyTrack?.parentElement;
const journeySticky = journeySection?.firstElementChild;

if (
  journeySection &&
  journeyTrack &&
  journeyViewport &&
  journeySticky &&
  journeySlots.length > 1
) {
  let sectionTop = 0;
  let scrollDistance = 0;
  let ticking = false;

  journeySection.id ||= "journey";
  journeySection.setAttribute("aria-label", "The journey so far");
  journeyViewport.style.overflow = "hidden";
  journeySticky.style.height = "100svh";

  const render = () => {
    const scrollRange = Math.max(
      1,
      journeySection.offsetHeight - journeySticky.offsetHeight,
    );
    const progress = Math.min(
      1,
      Math.max(0, (window.scrollY - sectionTop) / scrollRange),
    );

    journeyTrack.style.transform = `translate3d(${-progress * scrollDistance}px, 0, 0)`;
    ticking = false;
  };

  const measure = () => {
    journeyTrack.style.transform = "translate3d(0, 0, 0)";
    // Centre the first/last card in the viewport, as the live site does.
    const slotWidth = journeySlots[0].offsetWidth;
    journeyTrack.style.padding = `0 ${(journeyViewport.clientWidth - slotWidth) / 2}px`;
    scrollDistance = Math.max(
      0,
      journeyTrack.scrollWidth - journeyViewport.clientWidth,
    );

    // The live site spends ~0.73px of vertical scroll per horizontal pixel (2039px section at 1440px wide).
    journeySection.style.height = `${journeySticky.offsetHeight + Math.round(scrollDistance * 0.7287)}px`;
    sectionTop =
      journeySection.getBoundingClientRect().top + window.scrollY;
    render();
  };

  const requestRender = () => {
    if (!ticking) {
      ticking = true;
      window.requestAnimationFrame(render);
    }
  };

  window.addEventListener("scroll", requestRender, { passive: true });
  window.addEventListener("resize", measure);

  if (document.fonts?.ready) {
    document.fonts.ready.then(measure);
  } else {
    measure();
  }
}
