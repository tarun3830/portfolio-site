// Interaction layer for the static Framer export: smooth scroll, entrance /
// scroll reveals, scroll-linked text highlight and the testimonial ticker.
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const EASE_OUT = "cubic-bezier(0.22, 1, 0.36, 1)";

// ---- Page loader -----------------------------------------------------------
// Four panels cover the screen while "SANJAY  MENON" types in, then the
// panels collapse upwards (1s tween, staggered) to reveal the hero.
const LOADER_HOLD_MS = 1800;
const PANEL_EASE = "cubic-bezier(0.79, 0.04, 0.16, 1.03)";
const loader = document.querySelector(".framer-gyN1U");
const loaderRoot = document.querySelector(".framer-cvuhow-container");

const runLoader = () =>
  new Promise((resolve) => {
    const q = (sel) => [...loader.querySelectorAll(sel)];
    const wraps = q('[data-framer-name="Panel Wrap"]');
    const panels = q('[data-framer-name="Panel"]');
    const name = loader.querySelector('[data-framer-name="Profile Pic / Name"]');
    const dots = q('[data-framer-name^="dot"]');
    const delays = [0, 0.05, 0.08, 0.12];

    // Back to the "Load Innitial" variant.
    loader.classList.replace("framer-v-asq5g6", "framer-v-jwaya2");
    loader.dataset.framerName = "Load Innitial";
    wraps[0].style.backgroundColor = "rgb(255, 255, 255)";
    name.style.opacity = "1";
    document.documentElement.style.overflow = "hidden";

    panels.forEach((p) => (p.style.transformOrigin = "50% 0"));
    name.style.transition = "opacity 0.4s ease-out";

    // Letters drop in from above, 50ms apart (spring-like overshoot).
    loader.querySelectorAll("p.framer-text > span").forEach((word) => {
      [...word.children].forEach((ch, i) => {
        ch.style.transition = "none";
        ch.style.opacity = "0.001";
        ch.style.transform = "translateY(-20px)";
        setTimeout(() => {
          ch.style.transition = "opacity 0.5s ease-out, transform 0.6s cubic-bezier(0.34, 1.4, 0.64, 1)";
          ch.style.opacity = "1";
          ch.style.transform = "none";
        }, 50 + i * 50);
      });
    });

    // Dots hop one after another every 400ms.
    const hop = (i) => {
      dots.forEach((d, j) => {
        d.style.transition = "transform 0.6s cubic-bezier(0.34, 1.4, 0.64, 1), background-color 0.6s ease-out";
        d.style.transform = j === i ? "translate3d(0, -3px, 0)" : "translate3d(0, 0, 0)";
        d.style.backgroundColor = j === i ? "rgb(2, 129, 224)" : "rgba(2, 129, 224, 0.5)";
      });
    };
    let step = 0;
    hop(0);
    const dotTimer = setInterval(() => hop(++step % 3), 400);

    setTimeout(() => {
      clearInterval(dotTimer);
      // SANJAY slides off to the left and MENON to the right, dots fade out.
      const [left, right] = [".framer-174ja5d", ".framer-5ao13r"].map((s) => name.querySelector(s));
      const dotsBox = name.querySelector(".framer-1x8j3cr-container");
      const slide = { duration: 1000, easing: PANEL_EASE, fill: "forwards" };
      const leftDist = left.getBoundingClientRect().right + 40;
      const rightDist = window.innerWidth - right.getBoundingClientRect().left + 40;
      left.animate([{ transform: "translateX(0)" }, { transform: `translateX(${-leftDist}px)` }], slide);
      right.animate([{ transform: "translateX(0)" }, { transform: `translateX(${rightDist}px)` }], slide);
      dotsBox.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 300, fill: "forwards" });
      // Each panel's bottom edge slides up off the screen (transform-based so it
      // runs on the compositor and stays smooth), staggered left to right.
      panels.forEach((p, i) =>
        p.animate(
          [
            { transform: "translateY(0) scaleY(1)" },
            { transform: "translateY(-40px) scaleY(0.02)" },
          ],
          { duration: 1000, delay: delays[i] * 1000, easing: PANEL_EASE, fill: "forwards" },
        ),
      );
      wraps[0].animate(
        [{ backgroundColor: "rgb(255, 255, 255)" }, { backgroundColor: "rgba(255, 255, 255, 0)" }],
        { duration: 600, easing: "ease-out", fill: "forwards" },
      );
      loader.dataset.framerName = "Load Finish";
      document.documentElement.style.overflow = "";
      setTimeout(resolve, 500); // hero starts while the panels are still lifting
      setTimeout(() => (loaderRoot.style.display = "none"), 1300);
    }, LOADER_HOLD_MS);
  });

const hasLoader = Boolean(loader && loaderRoot);
const ready = hasLoader && !reduceMotion ? runLoader() : Promise.resolve();
document.getElementById("pre-load")?.remove();
if (hasLoader && reduceMotion) loaderRoot.style.display = "none";

// ---- Smooth scroll (Lenis) -------------------------------------------------
const loadLenis = () =>
  new Promise((resolve) => {
    const s = document.createElement("script");
    s.src = "https://unpkg.com/lenis@1.1.18/dist/lenis.min.js";
    s.onload = () => resolve(window.Lenis);
    s.onerror = () => resolve(null);
    document.head.appendChild(s);
  });

if (!reduceMotion) {
  loadLenis().then((Lenis) => {
    if (!Lenis) return;
    const lenis = new Lenis({ duration: 1.1, smoothWheel: true });
    const raf = (t) => {
      lenis.raf(t);
      requestAnimationFrame(raf);
    };
    requestAnimationFrame(raf);

    document.querySelectorAll('a[href^="./index.html#"], a[href^="#"]').forEach((a) => {
      a.addEventListener("click", (e) => {
        const id = a.getAttribute("href").split("#")[1];
        const target = id && document.getElementById(id);
        if (!target) return;
        e.preventDefault();
        lenis.scrollTo(target, { offset: 0 });
      });
    });
  });
}

// ---- Word-by-word blur reveal ---------------------------------------------
const revealGroups = new Map();
document
  .querySelectorAll('span[style*="inline-block"][style*="blur("]')
  .forEach((span) => {
    const parent = span.parentElement;
    if (!revealGroups.has(parent)) revealGroups.set(parent, []);
    revealGroups.get(parent).push(span);
  });

const wordBlur = (span) =>
  parseFloat(span.style.filter.match(/blur\(([\d.]+)px\)/)?.[1] || 0);

const hideWords = (words) =>
  words.forEach((w) => {
    w.style.transition = "none";
    w.style.opacity = "0";
    w.style.filter = `blur(${w.dataset.blur}px)`;
    w.style.transform = "translateY(10px)";
  });

const playWords = (words) =>
  words.forEach((w, i) => {
    w.style.transition = `opacity 0.6s ease-out ${i * 0.04}s, filter 0.6s ease-out ${i * 0.04}s, transform 0.6s ${EASE_OUT} ${i * 0.04}s`;
    w.style.opacity = "1";
    w.style.filter = "blur(0px)";
    w.style.transform = "none";
  });

if (!reduceMotion) {
  // Larger text blurs more (10px headings, 4px body), as on the live site.
  revealGroups.forEach((words) => {
    const size = parseFloat(getComputedStyle(words[0]).fontSize);
    words.forEach((w) => (w.dataset.blur = size >= 32 ? 10 : 4));
    hideWords(words);
  });

  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        io.unobserve(entry.target);
        ready.then(() => playWords(revealGroups.get(entry.target)));
      });
    },
    { threshold: 0.2, rootMargin: "0px 0px -8% 0px" },
  );
  revealGroups.forEach((_, parent) => io.observe(parent));
} else {
  revealGroups.forEach((words) =>
    words.forEach((w) => {
      w.style.opacity = "1";
      w.style.filter = "blur(0px)";
      w.style.transform = "none";
    }),
  );
}

// ---- Footer social pills: slide in from the right when scrolled into view --
const socialPills = [...document.querySelectorAll('a[data-framer-name*="delay"]')];
if (socialPills.length) {
  const hidden = socialPills.filter((a) => a.style.opacity === "0");
  const show = (a) => {
    const delay = /0\.1/.test(a.dataset.framerName) ? 0.1 : 0;
    a.style.transition = reduceMotion
      ? "none"
      : `opacity 0.6s ease-out ${delay}s, transform 0.6s ${EASE_OUT} ${delay}s`;
    a.style.opacity = "1";
    a.style.transform = "none";
  };
  if (reduceMotion) hidden.forEach(show);
  else if (hidden.length) {
    const io = new IntersectionObserver((entries) => {
      if (!entries.some((e) => e.isIntersecting)) return;
      io.disconnect();
      hidden.forEach(show);
    });
    io.observe(hidden[0].parentElement);
  }
}

// ---- Looping footer video: play while on screen ----------------------------
document.querySelectorAll("video").forEach((video) => {
  video.muted = true;
  video.loop = true;
  video.preload = "auto";
  const io = new IntersectionObserver(([entry]) => {
    if (entry.isIntersecting) video.play().catch(() => {});
    else video.pause();
  });
  io.observe(video);
});

// ---- "Back" pill: label always visible --------------------------------------
const backLink = [...document.querySelectorAll("a")].find((a) => a.textContent.trim() === "Back");
const backLabel = backLink?.querySelector('[style*="opacity:0"], [style*="opacity: 0"]');
if (backLabel) {
  backLabel.style.transition = "opacity 0.3s ease-out";
  backLabel.style.opacity = "1";
}

// ---- "Back" button (resume page) -------------------------------------------
document.querySelectorAll("[data-framer-name]").forEach((el) => {
  if (el.textContent.trim() !== "Back" || el.children.length > 6) return;
  const link = el.closest("a") || el;
  link.style.cursor = "pointer";
  link.addEventListener("click", (e) => {
    e.preventDefault();
    if (document.referrer.startsWith(location.origin)) history.back();
    else location.href = "./index.html";
  });
});

// ---- Hero / appear elements ------------------------------------------------
const appearStates = {
  "1jvs5nj": { from: "translateY(120px)", to: "none", dur: 1.2 },
  cdqbuk: {
    from: "translateX(-9px) translateY(-43px) rotate(-13deg)",
    to: "rotate(-2deg)",
    dur: 1.0,
  },
  n0ccwk: { from: "translateY(10px)", to: "none", dur: 0.6 },
  // Resume page
  "1obxrdw": {
    from: "translateY(240px) scale(1.3) rotate(-8deg) rotateY(24deg)",
    to: "rotate(-1deg)",
    dur: 1.2,
  },
  "1cn5ros": {
    from: "translateX(-9px) translateY(-43px) rotate(-13deg)",
    to: "rotate(-2deg)",
    dur: 1.0,
  },
};

document.querySelectorAll("[data-framer-appear-id]").forEach((el) => {
  const s = appearStates[el.dataset.framerAppearId];
  if (!s) return;
  const show = () => {
    el.style.transition = reduceMotion
      ? "none"
      : `opacity ${s.dur}s ease-out 0.2s, transform ${s.dur}s ${EASE_OUT} 0.2s`;
    el.style.opacity = "1";
    el.style.transform = s.to;
  };
  if (reduceMotion) return show();
  el.style.transition = "none";
  el.style.opacity = "0.001";
  el.style.transform = s.from;
  const io = new IntersectionObserver((entries) => {
    if (!entries.some((e) => e.isIntersecting)) return;
    io.disconnect();
    ready.then(show);
  });
  io.observe(el);
});

// ---- Scroll-linked highlight of the About statement ------------------------
const aboutHeading = [...document.querySelectorAll("h2")].find(
  (h) => getComputedStyle(h).position === "sticky",
);
const aboutWords = aboutHeading ? [...aboutHeading.querySelectorAll(":scope > span")] : [];

if (aboutWords.length && !reduceMotion) {
  const full = aboutWords.map((w) => getComputedStyle(w).color);
  const toAlpha = (color, a) => color.replace(/rgba?\(([^)]+)\)/, (_, v) => {
    const [r, g, b] = v.split(",").map((n) => parseFloat(n));
    return `rgba(${r}, ${g}, ${b}, ${a})`;
  });

  const update = () => {
    const rect = aboutHeading.getBoundingClientRect();
    const vh = window.innerHeight;
    // Measured on the live site: the first word lights when the paragraph's top
    // reaches the bottom of the viewport and the last one by ~10% from the top,
    // one word at a time (dim = 25% alpha + 1px blur, lit = full colour + sharp).
    const progress = clamp((vh - rect.top) / (vh * 0.9));
    const lit = Math.floor(progress * aboutWords.length);
    aboutWords.forEach((w, i) => {
      const on = i < lit;
      w.style.color = on ? full[i] : toAlpha(full[i], 0.25);
      w.style.filter = on ? "blur(0px)" : "blur(1px)";
    });
  };
  window.addEventListener("scroll", update, { passive: true });
  window.addEventListener("resize", update);
  update();
}

// ---- Testimonial ticker ----------------------------------------------------
const ticker = [...document.querySelectorAll("ul")].find((u) =>
  /will-change/.test(u.getAttribute("style") || ""),
);

if (ticker && !reduceMotion && ticker.children.length > 1) {
  const SPEED = 50; // px per second, leftwards
  const sets = 3;
  const per = ticker.children.length / sets;
  let offset = 0;
  let last = performance.now();
  let visible = true;
  new IntersectionObserver(([e]) => (visible = e.isIntersecting)).observe(ticker);

  const tick = (now) => {
    const dt = (now - last) / 1000;
    last = now;
    if (visible) {
      const gap = parseFloat(getComputedStyle(ticker).columnGap) || 0;
      const loop = [...ticker.children]
        .slice(0, per)
        .reduce((sum, c) => sum + c.offsetWidth + gap, 0);
      offset = (offset + SPEED * dt) % loop;
      ticker.style.transform = `translateX(${-offset}px)`;
    }
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

// ---- Testimonial card hover: clip tilts to -6deg, paper straightens ---------
document.querySelectorAll('[data-highlight][data-framer-name="Desktop"]').forEach((card) => {
  const all = [card, ...card.querySelectorAll("*")];
  const clip = all[1 + 4]; // descendant 4, rotate(-5deg)
  const paper = card; // rotate(0.5deg)
  if (!clip || !paper) return;
  const spring = "transform 0.5s cubic-bezier(0.34, 1.3, 0.64, 1)";
  clip.style.transition = paper.style.transition = spring;
  const set = (on) => {
    clip.style.transform = on ? "rotate(-6deg)" : "rotate(-5deg)";
    paper.style.transform = on ? "none" : "rotate(0.5deg)";
  };
  card.addEventListener("mouseenter", () => set(true));
  card.addEventListener("mouseleave", () => set(false));
});

// ---- Nav bar: collapses to "SANJAY " once you leave the hero --------------
// Scrolling down past the hero closes it (links fade out, dots fade in, pill
// narrows); scrolling back to the hero reopens it. Hovering the dots opens it.
const nav = document.querySelector("nav.framer-kmXIE");
if (nav && !reduceMotion) {
  const linksBox = nav.querySelector(".framer-1mq7lnf-container");
  const dotsBox = nav.querySelector(".framer-ej3mft-container");
  const OPEN_CLASS = "framer-v-2i6fwp";
  const CLOSED_CLASS = "framer-v-15es121";
  const NAV_EASE = "cubic-bezier(0.22, 1, 0.36, 1)";
  let mode = "default";
  let scrolled = false;
  let hovering = false;

  linksBox.style.transition = dotsBox.style.transition = "opacity 0.4s ease-out";
  nav.style.willChange = "width";

  const setMode = (next) => {
    if (next === mode) return;
    const closing = next === "closed";
    const from = nav.getBoundingClientRect().width;
    nav.style.width = "";
    nav.classList.toggle(CLOSED_CLASS, closing);
    nav.classList.toggle(OPEN_CLASS, !closing);
    nav.dataset.framerName = closing ? "Nav Closed" : next === "open" ? "Nav Open" : "Nav Default";
    linksBox.style.opacity = closing ? "0" : "1";
    linksBox.style.transform = closing ? "translateY(-50%)" : "none";
    dotsBox.style.opacity = closing ? "1" : "0";
    dotsBox.style.transform = closing ? "none" : "translateY(-50%)";
    const to = nav.getBoundingClientRect().width;
    mode = next;
    nav.getAnimations().forEach((a) => a.cancel());
    nav
      .animate([{ width: `${from}px` }, { width: `${to}px` }], {
        duration: 600,
        easing: NAV_EASE,
      })
      .finished.catch(() => {});
  };

  const evaluate = () => {
    if (!scrolled) return setMode("default");
    setMode(hovering ? "open" : "closed");
  };

  let lastY = window.scrollY;
  window.addEventListener(
    "scroll",
    () => {
      const y = window.scrollY;
      // Direction-based: any real scroll up opens the nav, scrolling down closes it.
      if (y > lastY + 2 && y > 50) scrolled = true;
      else if (y < lastY - 2 || y <= 50) scrolled = false;
      lastY = y;
      evaluate();
    },
    { passive: true },
  );
  dotsBox.addEventListener("mouseenter", () => {
    if (mode !== "closed") return;
    hovering = true;
    evaluate();
  });
  nav.addEventListener("mouseleave", () => {
    hovering = false;
    evaluate();
  });
}
